//
//  AdBrixRM.h
//  AdBrixRM
//
//  Created by igaworks on 2018. 3. 23..
//  Copyright © 2018년 igaworks. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IgaworksADUtil.h"
#import "Reachability.h"

FOUNDATION_EXPORT double AdBrixRMVersionNumber;

FOUNDATION_EXPORT const unsigned char AdBrixRMVersionString[];


